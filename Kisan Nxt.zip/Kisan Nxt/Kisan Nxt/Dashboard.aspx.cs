﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.IO;

namespace Kisan_Nxt
{
    public partial class Dashboard : System.Web.UI.Page
    {
        GetObjectsForFlask GOF = new GetObjectsForFlask();
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedValue != "" && DropDownList1.SelectedValue != string.Empty)
            {
                GOF.state = DropDownList1.SelectedItem.Text.ToString().ToUpper();
                GOF.imageOutput = @"M:\Madhuri\NASSCOM\Nasscom_hack-master\images";
                string sValue = text_key(GOF);
                //img1.ImageUrl = "~/Images/wordcloud.jpg";
                //img2.ImageUrl = @"M:\Madhuri\NASSCOM\Nasscom_hack-master\images\bar_chart.jpg";
                //Image1.ImageUrl = @"M:\Madhuri\NASSCOM\Nasscom_hack-master\images\line_chart.jpg";
                //Image2.ImageUrl = @"M:\Madhuri\NASSCOM\Nasscom_hack-master\images\heatmap.jpg";

            }
        }
        private string text_key(GetObjectsForFlask query)
        {
            string sResult = string.Empty;
            string inputJson = (new System.Web.Script.Serialization.JavaScriptSerializer()).Serialize(query);

            //oLog.WriteToDebugLogFile(inputJson, "text_key");

            HttpWebRequest httpRequest = (HttpWebRequest)WebRequest.Create(new Uri("http://192.168.106.70:6001/" + "built_plots"));
            try
            {
                httpRequest.ContentType = "application/json";
                httpRequest.Method = "POST";

                byte[] bytes = System.Text.Encoding.UTF8.GetBytes(inputJson);

                using (Stream stream = httpRequest.GetRequestStream())
                {
                    stream.Write(bytes, 0, bytes.Length);
                }
                HttpWebResponse httpResponse = (HttpWebResponse)httpRequest.GetResponse();
                using (Stream stream = httpResponse.GetResponseStream())
                {
                    sResult = (new StreamReader(stream)).ReadToEnd();
                    
                        // sResult = clsConstants.SUCCESS;
                       img1.ImageUrl= "~/Images/wordcloud.jpg";
                        img2.ImageUrl= "~/Images/bar_chart.jpg";
                        Image1.ImageUrl = "~/Images/line_chart.jpg";
                        Image2.ImageUrl = "~/Images/heatmap.jpg";

                   
                }
            }
            catch (Exception ex)
            {
                sResult = ex.Message.ToString();
            }
            return sResult;
        }

        //protected void Button1_Click(object sender, EventArgs e)
        //{
        //    //pnlImage.BackImageUrl=   //OpenFile(@"M:\Madhuri\NASSCOM\images.jpg"));
        //    imgOutput.ImageUrl = "~/Images/images.jpg";


        //}
    }
}