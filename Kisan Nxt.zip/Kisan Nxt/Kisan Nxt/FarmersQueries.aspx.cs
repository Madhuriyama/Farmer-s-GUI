﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace Kisan_Nxt
{
    public partial class FarmersQueries : System.Web.UI.Page
    {
        GetObjectsForFlask GOF = new GetObjectsForFlask();
        string path = System.Web.HttpContext.Current.Server.MapPath("~/Output/");
        string methodName = string.Empty;
        string sURL = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (!IsPostBack)
            {
                fupLoad.Enabled = false;
                fupLoad.Visible = false;
                btnUpload.Visible = false;
            }
            //if (!IsPostBack)
            //{
            //    fupLoad.SaveAs(path + Path.GetFileName(fupLoad.FileName));
            //    btn_Click(sender, e);

            //}


        }

        protected void btn_Click(object sender, EventArgs e)
        {
            if ( txtQuery.Text.ToString().ToLower().Contains("pesticide")|| txtQuery.Text.ToString().ToLower().Contains("insects")|| txtQuery.Text.ToString().ToLower().Contains("affected") || txtQuery.Text.ToString().ToLower().Contains("attack"))
            {
                fupLoad.Enabled = true;
                fupLoad.Visible = true;
                btnUpload.Visible = true;
               
            }
            else
            {
               
                GOF.query = txtQuery.Text;
                methodName = "query_interface/respond_to_query";
                sURL = "http://192.168.106.51:6001/";
                string sResult = text_key(GOF);
                 //"test"  " http://192.168.106.70:6001/ " "
            }

          
        }

        private string text_key(GetObjectsForFlask query)
        {
            string sResult = string.Empty;
            string inputJson = (new System.Web.Script.Serialization.JavaScriptSerializer()).Serialize(query);

            //oLog.WriteToDebugLogFile(inputJson, "text_key");

            HttpWebRequest httpRequest = (HttpWebRequest)WebRequest.Create(new Uri(sURL + methodName));
            try
            {
                httpRequest.ContentType = "application/json";
                httpRequest.Method = "POST";

                byte[] bytes = System.Text.Encoding.UTF8.GetBytes(inputJson);

                using (Stream stream = httpRequest.GetRequestStream())
                {
                    stream.Write(bytes, 0, bytes.Length);
                }
                HttpWebResponse httpResponse = (HttpWebResponse)httpRequest.GetResponse();
                using (Stream stream = httpResponse.GetResponseStream())
                {
                    sResult = (new StreamReader(stream)).ReadToEnd();
                    if (sResult != string.Empty)
                    {
                        if (methodName == "image_recognition")
                        {

                            sResult = sResult.ToString().Replace("\\", "").Replace("\"", "");



                            string s = txtQuery.Text + " " + sResult;

                            GOF.query = s;
                            sURL = "http://192.168.106.51:6001/";
                            methodName = "query_interface/respond_to_query";
                            sResult = text_key(GOF);

                        }
                        else
                        {
                            sResult = sResult.ToString().Replace("\\", "").Replace("\"", "");
                            sResult = sResult.Substring(0, sResult.IndexOf(",")).Replace("{response:", "");
                            txtResponse.Text = sResult;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                sResult = ex.Message.ToString();
            }
            return sResult;
        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            fupLoad.SaveAs(path + Path.GetFileName(fupLoad.FileName));
            path = path + Path.GetFileName(fupLoad.FileName);
            GOF.img = path; // + Path.GetFileName(fupLoad.FileName);//@"M:\Madhuri\NASSCOM\Nasscom_hack-master\images\leafminer\leafminer1.jpg";
            sURL = "http://192.168.106.70:6001/";
            methodName = "image_recognition";
            
            string sResult = text_key(GOF);
            
        }

        protected void btnWeather_Click(object sender, EventArgs e)
        {
            Response.Redirect("WebForm.aspx");
        }
    }
}