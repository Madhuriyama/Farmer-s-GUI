﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;

namespace Kisan_Nxt
{
    public partial class Login : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!File.Exists(@"M:\Madhuri\NASSCOM\Kisan Nxt\Kisan Nxt\Output\Credentials.xml"))
                Credentials();
        }

        public void Credentials()
        {
            DataTable dt = new DataTable("Credentials");
            dt.Columns.Add("Username");
            dt.Columns.Add("Password");
            DataRow dr = dt.NewRow();

            dr["username"] = "Kisan";
            dr["Password"] = "kisan123";
            dt.Rows.Add(dr);
            DataRow dr1 = dt.NewRow();

            dr1["username"] = "Admin";
            dr1["Password"] = "admin123";
            dt.Rows.Add(dr1);
            dt.AcceptChanges();

            dt.WriteXml(@"M:\Madhuri\NASSCOM\Kisan Nxt\Kisan Nxt\Output\Credentials.xml", true);

        }

        protected void btnSignIn_Click(object sender, EventArgs e)
        {
            
            DataSet dtcredtials = new DataSet();
            //using (Stream stream = new FileStream(@"M:\Madhuri\NASSCOM\Kisan Nxt\Kisan Nxt\Output\Credentials.xml", FileMode.Open, FileAccess.Read))
                dtcredtials.ReadXml(@"M:\Madhuri\NASSCOM\Kisan Nxt\Kisan Nxt\Output\Credentials.xml");
            foreach (DataRow dr in dtcredtials.Tables[0].Rows)
            {
                if (dr["username"].ToString() == txtUserName.Text)
                {
                    if (dr["Password"].ToString() == txtPassword.Text)
                    {
                        if (txtUserName.Text == "Kisan")
                            Response.Redirect("FarmersQueries.aspx");
                        else Response.Redirect("Dashboard.aspx");
                    }
                    else lblError.Text = "Please Enter Correct Password";
                }
                else lblError.Text = "Username doesn't exist";
            }

        }
    }
}