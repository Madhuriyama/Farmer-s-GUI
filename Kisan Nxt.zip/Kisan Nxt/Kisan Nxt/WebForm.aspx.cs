﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.IO;


namespace Kisan_Nxt
{
    public partial class WebForm : System.Web.UI.Page
    {
        GetObjectsForFlask GOF = new GetObjectsForFlask();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            GOF.city = txtCity.Text;
            string sResult = text_key(GOF);
        }

        private string text_key(GetObjectsForFlask query)
        {
            string sResult = string.Empty;
            string inputJson = (new System.Web.Script.Serialization.JavaScriptSerializer()).Serialize(query);

            //oLog.WriteToDebugLogFile(inputJson, "text_key");

            HttpWebRequest httpRequest = (HttpWebRequest)WebRequest.Create(new Uri("http://192.168.106.70:6001/" + "weather"));
            try
            {
                httpRequest.ContentType = "application/json";
                httpRequest.Method = "POST";

                byte[] bytes = System.Text.Encoding.UTF8.GetBytes(inputJson);

                using (Stream stream = httpRequest.GetRequestStream())
                {
                    stream.Write(bytes, 0, bytes.Length);
                }
                HttpWebResponse httpResponse = (HttpWebResponse)httpRequest.GetResponse();
                using (Stream stream = httpResponse.GetResponseStream())
                {
                    sResult = (new StreamReader(stream)).ReadToEnd();

                    // sResult = clsConstants.SUCCESS;
                    sResult = sResult.ToString().Replace("\\", "").Replace("\"", "");
                    string s = sResult.Substring(0, sResult.IndexOf(",")).Replace("{response:", "").Replace("{Text:", "");
                    string temp = sResult.Split(new string[] { "Temp:" }, StringSplitOptions.None)[1].Replace("}}","");
                        TextBox2.Text = "Weather:"+s +"\n"+"Temperature:"+temp;

                }
            }
            catch (Exception ex)
            {
                sResult = ex.Message.ToString();
            }
            return sResult;
        }
    }
}